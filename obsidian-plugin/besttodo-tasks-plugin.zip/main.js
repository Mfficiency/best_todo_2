"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => BestToDoPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian2 = require("obsidian");

// src/model.ts
var SUPPORTED_SYNC_VERSION = 1;
var FUTURE_SENTINEL = { year: 2300, month: 1, day: 1 };
var SECTION_TITLES = [
  "Today",
  "Tomorrow",
  "Day After Tomorrow",
  "Next Week",
  "Next Month",
  "Future"
];
var FUTURE_TAB_INDEX = 5;
var SyncContractError = class extends Error {
};
function parseDate(value) {
  if (typeof value !== "string" || value.length === 0) return null;
  const dateOnly = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (dateOnly) {
    return new Date(
      Number(dateOnly[1]),
      Number(dateOnly[2]) - 1,
      Number(dateOnly[3])
    );
  }
  const parsed = new Date(value);
  return isNaN(parsed.getTime()) ? null : parsed;
}
function parseTask(json) {
  const legacyDue = parseDate(json["dueDate"]);
  let end = parseDate(json["endAt"]);
  end != null ? end : end = legacyDue;
  return {
    uid: typeof json["uid"] === "string" ? json["uid"] : "",
    title: typeof json["title"] === "string" ? json["title"] : "",
    isDone: json["isDone"] === true,
    dueDate: end,
    completedAt: parseDate(json["completedAt"]),
    deletedAt: parseDate(json["deletedAt"]),
    label: typeof json["label"] === "string" ? json["label"] : "",
    projectId: typeof json["projectId"] === "string" ? json["projectId"] : null,
    listRanking: typeof json["listRanking"] === "number" ? json["listRanking"] : null,
    hasExplicitTime: json["hasExplicitTime"] === true,
    isRecurring: json["isRecurring"] === true
  };
}
function parseSyncFile(contents) {
  let data;
  try {
    data = JSON.parse(contents);
  } catch {
    throw new SyncContractError("The sync file is not valid JSON.");
  }
  if (typeof data !== "object" || data === null || Array.isArray(data)) {
    throw new SyncContractError(
      "The sync file is not a BestToDo sync envelope."
    );
  }
  const envelope = data;
  const version = envelope["sync_version"];
  if (version !== SUPPORTED_SYNC_VERSION) {
    throw new SyncContractError(
      `Unsupported sync_version ${String(version)} \u2014 this plugin understands version ${SUPPORTED_SYNC_VERSION}. Update the plugin or the app.`
    );
  }
  const rawTasks = envelope["tasks"];
  const tasks = [];
  if (Array.isArray(rawTasks)) {
    for (const raw of rawTasks) {
      if (typeof raw === "object" && raw !== null && !Array.isArray(raw)) {
        tasks.push(parseTask(raw));
      }
    }
  }
  return {
    syncVersion: SUPPORTED_SYNC_VERSION,
    syncedAt: parseDate(envelope["synced_at"]),
    appVersion: typeof envelope["app_version"] === "string" ? envelope["app_version"] : "",
    taskCount: typeof envelope["task_count"] === "number" ? envelope["task_count"] : tasks.length,
    tasks
  };
}
function isFutureSentinel(date) {
  return date.getFullYear() === FUTURE_SENTINEL.year && date.getMonth() + 1 === FUTURE_SENTINEL.month && date.getDate() === FUTURE_SENTINEL.day;
}
function dateDiffInDays(from, to) {
  const fromDay = Date.UTC(from.getFullYear(), from.getMonth(), from.getDate());
  const toDay = Date.UTC(to.getFullYear(), to.getMonth(), to.getDate());
  return Math.round((fromDay - toDay) / 864e5);
}
function bucketIndex(task, today) {
  const due = task.dueDate;
  if (due === null) return FUTURE_TAB_INDEX;
  if (isFutureSentinel(due)) return FUTURE_TAB_INDEX;
  const diff = dateDiffInDays(due, today);
  if (diff <= 0) return 0;
  if (diff === 1) return 1;
  if (diff === 2) return 2;
  if (diff < 30) return 3;
  return 4;
}
function compareTasks(a, b) {
  var _a, _b;
  const doneCompare = (a.isDone ? 1 : 0) - (b.isDone ? 1 : 0);
  if (doneCompare !== 0) return doneCompare;
  const rankA = (_a = a.listRanking) != null ? _a : 2 ** 31;
  const rankB = (_b = b.listRanking) != null ? _b : 2 ** 31;
  return rankA - rankB;
}
function buildBuckets(tasks, today) {
  const buckets = SECTION_TITLES.map(() => []);
  for (const task of tasks) {
    if (task.deletedAt !== null) continue;
    buckets[bucketIndex(task, today)].push(task);
  }
  for (const bucket of buckets) {
    bucket.sort(compareTasks);
  }
  return buckets;
}
var two = (n) => String(n).padStart(2, "0");
function formatDate(d) {
  return `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}`;
}
function formatDateTime(d) {
  return `${formatDate(d)} ${two(d.getHours())}:${two(d.getMinutes())}`;
}

// src/view.ts
var import_obsidian = require("obsidian");
var VIEW_TYPE_BESTTODO = "besttodo-tasks";
var BestToDoView = class extends import_obsidian.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
  }
  getViewType() {
    return VIEW_TYPE_BESTTODO;
  }
  getDisplayText() {
    return "BestToDo tasks";
  }
  getIcon() {
    return "check-circle";
  }
  async onOpen() {
    await this.refresh();
  }
  /** Re-reads the sync file and re-renders; called on open and file change. */
  async refresh() {
    const container = this.contentEl;
    container.empty();
    container.addClass("besttodo-view");
    let file;
    try {
      file = await this.plugin.readSyncFile();
    } catch (error) {
      this.renderError(container, error);
      return;
    }
    this.renderFile(container, file);
  }
  renderError(container, error) {
    const message = error instanceof SyncContractError ? error.message : `Could not read "${this.plugin.settings.syncFilePath}". Check the file path in the BestToDo Tasks settings.`;
    container.createEl("div", {
      cls: "besttodo-error",
      text: message
    });
  }
  renderFile(container, file) {
    const header = container.createEl("div", { cls: "besttodo-header" });
    const open = file.tasks.filter(
      (t) => t.deletedAt === null && !t.isDone
    ).length;
    const total = file.tasks.filter((t) => t.deletedAt === null).length;
    header.createEl("div", {
      cls: "besttodo-counts",
      text: `${open} open / ${total} total`
    });
    if (file.syncedAt !== null) {
      header.createEl("div", {
        cls: "besttodo-synced-at",
        text: `as of ${formatDateTime(file.syncedAt)}` + (file.appVersion ? ` \xB7 BestToDo ${file.appVersion}` : "")
      });
    }
    const buckets = buildBuckets(file.tasks, /* @__PURE__ */ new Date());
    let any = false;
    for (let tab = 0; tab < SECTION_TITLES.length; tab++) {
      const bucket = buckets[tab];
      if (bucket.length === 0) continue;
      any = true;
      const section = container.createEl("div", { cls: "besttodo-section" });
      section.createEl("h4", {
        cls: "besttodo-section-title",
        text: SECTION_TITLES[tab]
      });
      const list = section.createEl("div", { cls: "besttodo-list" });
      for (const task of bucket) {
        this.renderTask(list, task);
      }
    }
    if (!any) {
      container.createEl("div", {
        cls: "besttodo-empty",
        text: "No tasks in the sync file."
      });
    }
  }
  renderTask(list, task) {
    const row = list.createEl("div", {
      cls: task.isDone ? "besttodo-task is-done" : "besttodo-task"
    });
    const checkbox = row.createEl("input", {
      cls: "besttodo-checkbox",
      type: "checkbox"
    });
    checkbox.checked = task.isDone;
    checkbox.disabled = true;
    const body = row.createEl("div", { cls: "besttodo-task-body" });
    body.createEl("span", { cls: "besttodo-title", text: task.title });
    const due = task.dueDate;
    if (due !== null && !isFutureSentinel(due)) {
      body.createEl("span", {
        cls: "besttodo-date",
        text: `\u{1F4C5} ${formatDate(due)}`
      });
    }
    if (task.isDone && task.completedAt !== null) {
      body.createEl("span", {
        cls: "besttodo-date",
        text: `\u2705 ${formatDate(task.completedAt)}`
      });
    }
    if (task.isRecurring) {
      body.createEl("span", { cls: "besttodo-date", text: "\u{1F501}" });
    }
    if (task.label !== "") {
      body.createEl("span", { cls: "besttodo-chip", text: task.label });
    }
    if (task.projectId !== null) {
      const chip = body.createEl("span", {
        cls: "besttodo-chip besttodo-chip-project",
        text: "\u{1F4C1} project"
      });
      chip.setAttribute("title", task.projectId);
    }
  }
  async onClose() {
    this.contentEl.empty();
  }
};

// src/main.ts
var DEFAULT_SETTINGS = {
  syncFilePath: "besttodo_tasks.json"
};
var BestToDoPlugin = class extends import_obsidian2.Plugin {
  constructor() {
    super(...arguments);
    this.settings = { ...DEFAULT_SETTINGS };
  }
  async onload() {
    await this.loadSettings();
    this.registerView(
      VIEW_TYPE_BESTTODO,
      (leaf) => new BestToDoView(leaf, this)
    );
    this.addRibbonIcon("check-circle", "Open BestToDo tasks", () => {
      void this.activateView();
    });
    this.addCommand({
      id: "open-view",
      name: "Open task view",
      callback: () => void this.activateView()
    });
    this.registerEvent(
      this.app.vault.on("modify", (file) => {
        if (file.path === (0, import_obsidian2.normalizePath)(this.settings.syncFilePath)) {
          void this.refreshViews();
        }
      })
    );
    this.registerEvent(
      this.app.vault.on("create", (file) => {
        if (file.path === (0, import_obsidian2.normalizePath)(this.settings.syncFilePath)) {
          void this.refreshViews();
        }
      })
    );
    this.addSettingTab(new BestToDoSettingTab(this.app, this));
  }
  onunload() {
  }
  /** Reads and parses the sync file; throws SyncContractError on refusal. */
  async readSyncFile() {
    const path = (0, import_obsidian2.normalizePath)(this.settings.syncFilePath);
    const adapter = this.app.vault.adapter;
    if (!await adapter.exists(path)) {
      throw new SyncContractError(
        `"${path}" was not found in this vault. Point the BestToDo sync folder into the vault, or set the file path in the plugin settings.`
      );
    }
    const contents = await adapter.read(path);
    return parseSyncFile(contents);
  }
  async activateView() {
    const { workspace } = this.app;
    const existing = workspace.getLeavesOfType(VIEW_TYPE_BESTTODO);
    let leaf;
    if (existing.length > 0) {
      leaf = existing[0];
    } else {
      leaf = workspace.getRightLeaf(false);
      if (leaf === null) {
        new import_obsidian2.Notice("Could not open the BestToDo view.");
        return;
      }
      await leaf.setViewState({ type: VIEW_TYPE_BESTTODO, active: true });
    }
    void workspace.revealLeaf(leaf);
  }
  async refreshViews() {
    for (const leaf of this.app.workspace.getLeavesOfType(
      VIEW_TYPE_BESTTODO
    )) {
      const view = leaf.view;
      if (view instanceof BestToDoView) {
        await view.refresh();
      }
    }
  }
  async loadSettings() {
    var _a;
    this.settings = { ...DEFAULT_SETTINGS, ...(_a = await this.loadData()) != null ? _a : {} };
  }
  async saveSettings() {
    await this.saveData(this.settings);
    await this.refreshViews();
  }
};
var BestToDoSettingTab = class extends import_obsidian2.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    new import_obsidian2.Setting(containerEl).setName("Sync file path").setDesc(
      "Vault-relative path to besttodo_tasks.json (the file BestToDo's synced mode writes). Default: vault root."
    ).addText(
      (text) => text.setPlaceholder(DEFAULT_SETTINGS.syncFilePath).setValue(this.plugin.settings.syncFilePath).onChange(async (value) => {
        this.plugin.settings.syncFilePath = value.trim() === "" ? DEFAULT_SETTINGS.syncFilePath : value.trim();
        await this.plugin.saveSettings();
      })
    );
  }
};
